# -*- coding: utf-8 -*-
from . import hr_employee
from . import hr_payslip
from . import hr_salary_distribution
from . import hr_contract
