# -*- coding: utf-8 -*-

from . import models
from . import inspection_team_inherit
from . import vehicle_required_service_inherit
from . import project_task_inherit
from . import vehicle_bay
from . import vehicle_health_report

