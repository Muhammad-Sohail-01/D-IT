# -*- coding: utf-8 -*-

from . import hr_payslip
from . import hr_payroll_structure
from . import salary_advance
