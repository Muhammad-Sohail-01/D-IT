import base64
import logging
from odoo.http import request, route
from odoo import http, tools, _
from odoo.addons.tk_vehicle_management.controllers.main import 