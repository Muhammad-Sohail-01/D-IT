from . import product_category
# from . import job_card_service_inherit
# from . import job_card_part_inherit
from . import product_template
from . import res_users
from . import sale_order_line
from . import sale_order
