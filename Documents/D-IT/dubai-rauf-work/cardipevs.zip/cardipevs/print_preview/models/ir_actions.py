# -*- coding: utf-8 -*-

from odoo import fields, models


class IrActionsReportXml(models.Model):
    _inherit = 'ir.actions.report'

    default_print_option = fields.Selection([
            ('print', 'Print'),
            ('download', 'Download'),
            ('open', 'Open'),
            ('whatsapp', 'Share on WhatsApp'),
            ('email', 'Email Report')
            ], string='Default printing option')

    def _get_readable_fields(self):
        readable_fields = super()._get_readable_fields()
        readable_fields.add('default_print_option')
        return readable_fields

    def report_action(self, docids, data=None, config=True):
        action = super().report_action(docids, data, config)
        action['context'] = action.get('context', {})
        action['context']['default_print_option'] = self.default_print_option
        return action