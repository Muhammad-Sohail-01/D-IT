# -*- coding: utf-8 -*---

from . import warranty_confirmation_wizard
