from . import sale_order
from . import product_template
from . import res_partner_ext
from . import sale_product_ext
