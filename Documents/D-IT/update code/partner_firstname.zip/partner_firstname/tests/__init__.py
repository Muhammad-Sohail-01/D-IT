from . import (
    test_create,
    test_defaults,
    test_delete,
    test_empty,
    test_name,
    test_partner_form,
    test_user_form,
    test_order,
    test_copy,
    test_config_settings,
)
