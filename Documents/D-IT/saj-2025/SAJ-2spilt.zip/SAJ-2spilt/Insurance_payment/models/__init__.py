# -*- coding: utf-8 -*-

from . import insurance_payment
from . import res_partner