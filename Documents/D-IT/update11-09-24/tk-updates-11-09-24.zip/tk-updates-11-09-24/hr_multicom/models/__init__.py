# -*- coding: utf-8 -*-

from . import hr_multicom
from . import hr_payslip_ext
from . import hr_payslip_input_type_ext