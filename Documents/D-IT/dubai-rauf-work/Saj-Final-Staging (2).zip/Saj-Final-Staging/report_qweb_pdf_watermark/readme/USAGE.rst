To use this module, you need to:

#. go to your report
#. select a PDF or image to use as watermark. Note that resolutions and size must match, otherwise you'll have funny results
#. You can also fill in an expression that returns the data (base64 encoded) to be used as watermark

To use the Company watermark, you need to:

#. go to settings --> company --> update info
#. upload an pdf watermark
#. go to settings --> technical --> reporting --> reports
#. Select the report where you want to use it.
#. On the 'Advanced Properties' tab of the notebook check 'use company watermark'

### Demo
And demo report is available (if you have demo data installed) on the users form view.

#. go to Configuration --> users
#. Select an users
#. Click the print button --> Watermark Demo report.
