# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError



class VehicleBayManagement(models.Model):
    _name = 'vehicle.bay'
    _description = 'vehicle Bay Management'

    name = fields.Char(string="Bay Name")
    bay_type = fields.Char(string="Bay Type")
    car_count = fields.Integer(string="Car Count")
    company_id = fields.Many2one('res.company', string="Company")
