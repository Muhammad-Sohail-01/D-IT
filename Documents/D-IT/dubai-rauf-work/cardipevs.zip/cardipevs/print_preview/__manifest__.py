# -*- coding: utf-8 -*-
{
    'name': 'Print Preview Email Options',
    'summary': """print preview download email options""",
    'description': """
        This module adds functionality to handle print preview, download and email options within Odoo.
    """,
     "author": "Rauff Imasdeen",
    "email": "rauffmimas@gmailcom",
    "mobile": "+971 5828 78 939",
    "version": "17.0",
    'category': 'technical',
    'version': '17.0.1.1.0',
    'depends': ['web'],
    'data': [
        'views/ir_actions_report.xml',
        #'views/report_pdf_options.xml'
    ],
    'installable': True,
    'auto_install': False,
    'license': 'LGPL-3',

    'assets': {
        'web.assets_backend': [
            'print_preview/static/src/js/PdfOptionsModal.js',
            'print_preview/static/src/js/qwebactionmanager.js',
            'print_preview/static/src/**/*.xml'
        ]
    }
}
