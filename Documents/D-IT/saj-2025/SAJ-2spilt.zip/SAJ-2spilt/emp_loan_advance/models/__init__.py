from . import hr_loan
from . import hr_loan_type
from . import hr_loan_installment
