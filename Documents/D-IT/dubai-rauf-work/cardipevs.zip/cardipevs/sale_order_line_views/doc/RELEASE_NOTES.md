## Module <odoo_sale_order_line_views>

- Initial Commit for Sale Order Line Views
