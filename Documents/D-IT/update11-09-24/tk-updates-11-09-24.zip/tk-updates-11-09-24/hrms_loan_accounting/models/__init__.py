# -*- coding: utf-8 -*-

from . import account_move_line
from . import hr_loan
from . import hr_loan_line
from . import hr_payslip
from . import res_config_settings
