# from odoo import fields, models
#
#
# class AccountMoveLine(models.Model):
#     """ Inheriting account move line for adding field. """
#     _inherit = "account.move.line"
#
#     loan_id = fields.Many2one(comodel_name='hr.payslip', string='MulticomId',)