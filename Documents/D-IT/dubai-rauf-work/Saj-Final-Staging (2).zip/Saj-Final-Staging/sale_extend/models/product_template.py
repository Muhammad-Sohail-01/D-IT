
from odoo import api, fields, models


class ProductTemplate(models.Model):
    _inherit = "product.template"
    
    car_brand_id = fields.Many2one('car.brand', string="Brand")