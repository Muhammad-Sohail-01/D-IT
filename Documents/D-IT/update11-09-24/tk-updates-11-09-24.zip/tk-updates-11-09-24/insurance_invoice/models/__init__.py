# -*- coding: utf-8 -*-

from . import models
from . import sale_order_line_ext
from . import res_company_insurance_inherit
