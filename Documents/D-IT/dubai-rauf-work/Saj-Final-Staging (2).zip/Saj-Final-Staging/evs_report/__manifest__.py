# -*- coding: utf-8 -*-

{
	"name" : "EVS Report",
	"version" : "17.0.0.1",
	"category" : "",
	'summary': 'Carlab module',
	"description": """
	
	""",
	"author": "Rauff Imasdeen",
	"website" : "",
	"currency": 'EUR',
	"depends" : ['base','stock','sale','sale_management'],
	"data": [
		'report/evs_report.xml',
		'report/estimation_inspection_report_template.xml',
		'report/tax_invoice_report_template.xml',
		'report/job_card_report_template.xml',
	],
	"auto_install": False,
	"installable": True,
	"live_test_url":'youtube link',
	"images":[""],
}
