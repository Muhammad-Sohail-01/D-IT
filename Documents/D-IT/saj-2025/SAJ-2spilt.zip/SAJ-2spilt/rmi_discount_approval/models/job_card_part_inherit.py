from odoo import api, fields, models, _
from odoo.exceptions import ValidationError




class VehicleRequiredParts(models.Model):
    _inherit = 'vehicle.required.parts'






