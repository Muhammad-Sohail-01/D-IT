# -*- coding: utf-8 -*-

{
    "name": "Serial Lot Number auto genaration",
    "author": "Rauff Imasdeen",
    "email": "rauffmimas@gmailcom",
    "mobile": "0+971 5828 78 939",
    "version": "17.0",
    "license": "OPL-1",
    "depends": ['stock', 'sale_management', 'purchase'],
    "category": "Sales",
    "summary": "Using this application you can can create serial lot number automaticly while confirming purchase order.",
    "description": "",
    "data": ['views/serial_no.xml',],
    "installable": True,

}
