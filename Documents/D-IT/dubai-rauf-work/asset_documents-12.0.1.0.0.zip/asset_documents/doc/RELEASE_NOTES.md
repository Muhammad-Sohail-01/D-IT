## Module <asset_documents>

#### 19.03.2019
#### Version 12.0.1.0.0
##### ADD
- Initial commit
